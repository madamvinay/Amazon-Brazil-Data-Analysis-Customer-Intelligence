SET search_path TO amazon_brazil;

CREATE TABLE customers(
	customer_id VARCHAR(50),
	customer_unique_id VARCHAR(50),
	customer_zip_code_prefix VARCHAR(10)
);

CREATE TABLE order_items(
	order_id VARCHAR(50),
	order_item_id INT,
	product_id VARCHAR(50),
	seller_id VARCHAR(50),
	shipping_limit_date TIMESTAMP,
	price FLOAT,
	freight_value FLOAT
);

CREATE TABLE payments(
	order_id VARCHAR(50),
	payment_sequential INT,
	payment_type VARCHAR(50),
	payment_installments INT,
	payment_value FLOAT
);

CREATE TABLE orders(
	order_id VARCHAR(50),
	customer_id VARCHAR(50),
	order_status VARCHAR(30),
	order_purchase_timestamp TIMESTAMP,
	order_approved_at TIMESTAMP,
	order_delivered_carrier_date TIMESTAMP,
	order_delivered_customer_date TIMESTAMP,
	order_estimated_delivery_date TIMESTAMP
);

CREATE TABLE product(
	product_id VARCHAR(50),
	product_category_name VARCHAR(50),
	product_name_length INT,
	product_description_length INT,
	product_photos_qty INT,
	product_weight_g INT,
	product_length_cm INT,
	product_height_cm INT,
	product_width_cm INT
);

CREATE TABLE sellers(
	seller_id VARCHAR(50),
	seller_zip_code_prefix VARCHAR(10)
);


SELECT * FROM customers;

SELECT * FROM order_items;

SELECT * FROM orders;

SELECT * FROM payments;

SELECT * FROM product;

SELECT * FROM sellers;

--------------------------------------------------------------------------------------


-- Analysis - I
----------------

/*
Q1. To simplify its financial reports, Amazon India needs to standardize payment 
values. Round the average payment values to integer (no decimal) for each payment 
type and display the results sorted in ascending order.
*/

SELECT payment_type, ROUND(AVG(payment_value)::numeric, 0) AS rounded_avg_payment
FROM payments
GROUP BY payment_type
ORDER BY rounded_avg_payment ASC;

-- Credit card has highest avg payment value.

--------------------------------------------------------------------------------------

/*
Q2. To refine its payment strategy, Amazon India wants to know the distribution of 
orders by payment type. Calculate the percentage of total orders for each payment type, 
rounded to one decimal place, and display them in descending order
*/


SELECT payments.payment_type, 
	ROUND((COUNT(orders.order_id)*100/ (
			SELECT COUNT(*)
			FROM orders INNER JOIN payments 
			ON orders.order_id = payments.order_id
	)),1) AS percentage_orders
FROM orders INNER JOIN payments 
ON orders.order_id = payments.order_id
GROUP BY payments.payment_type
ORDER BY percentage_orders DESC;

-- Credit card payments contributes 73%.

--------------------------------------------------------------------------------------

/*
Q3. Amazon India seeks to create targeted promotions for products within specific 
price ranges. Identify all products priced between 100 and 500 BRL that contain the 
word 'Smart' in their name. Display these products, sorted by price in descending 
order.
*/

SELECT order_items.product_id,order_items.price
FROM order_items INNER JOIN product
ON order_items.product_id = product.product_id
WHERE LOWER(product_category_name) LIKE '%smart%' AND price BETWEEN 100 AND 500
ORDER BY price DESC;

-- There are 34 products which amazon can target for promotions.

--------------------------------------------------------------------------------------

/*
Q4. To identify seasonal sales patterns, Amazon India needs to focus on the most 
successful months. Determine the top 3 months with the highest total sales value, 
rounded to the nearest integer.
*/


ALTER TABLE orders
ADD ordered_month VARCHAR(20);

UPDATE orders
SET ordered_month = TO_CHAR(order_purchase_timestamp, 'Month');

SELECT orders.ordered_month AS month_, ROUND(SUM(payments.payment_value)::numeric,0) AS total_sales 
FROM orders INNER JOIN payments
ON orders.order_id = payments.order_id
GROUP BY orders.ordered_month
ORDER BY total_sales DESC
LIMIT 3
OFFSET 0;

-- May, August, July are the top 3 months with highest total sales value.

-------------------------------------------------------------------------------------

/*
Q5. Amazon India is interested in product categories with significant price 
variations. Find categories where the difference between the maximum and minimum 
product prices is greater than 500 BRL.
*/

SELECT product.product_category_name, (MAX(order_items.price) - MIN(order_items.price)) AS price_difference
FROM product INNER JOIN order_items
ON product.product_id = order_items.product_id
GROUP BY product.product_category_name
HAVING (MAX(order_items.price) - MIN(order_items.price)) > 500.0
ORDER BY price_difference DESC;

-- There are 57 product categories which amazon is interested with significant price 
-- variations.

-------------------------------------------------------------------------------------

/*
Q6. To enhance the customer experience, Amazon India wants to find which payment types 
have the most consistent transaction amounts. Identify the payment types with the 
least variance in transaction amounts, sorting by the smallest standard deviation 
first.
*/

SELECT payments.payment_type, STDDEV_SAMP(order_items.price) AS std_deviation
FROM order_items INNER JOIN payments
ON order_items.order_id = payments.order_id
GROUP BY payments.payment_type
ORDER BY std_deviation ASC;

-- voucher payment type has most consistant transaction amounts.

--------------------------------------------------------------------------------------

/*
Q7. Amazon India wants to identify products that may have incomplete name in order to 
fix it from their end. Retrieve the list of products where the product category 
name is missing or contains only a single character.
*/

SELECT product_id, product_category_name FROM product
WHERE product_category_name IS NULL OR CHAR_LENGTH(product_category_name) = 1;

-- There are 614 Products with product category belongs to null or single value.

-------------------------------------------------------------------------------------


-- Analysis - II
------------------
/*
Q1. Amazon India wants to understand which payment types are most popular across 
different order value segments (e.g., low, medium, high). Segment order values into 
three ranges: orders less than 200 BRL, between 200 and 1000 BRL, and over 1000 BRL. 
Calculate the count of each payment type within these ranges and display the results 
in descending order of count
*/

ALTER TABLE payments
ADD COLUMN order_value_segment VARCHAR(20);

UPDATE payments
SET order_value_segment = CASE
	WHEN payment_value < 200 THEN 'low'
	WHEN payment_value BETWEEN 200 AND 1000 THEN 'medium'
	ELSE 'high'
END; 

SELECT payments.order_value_segment, payments.payment_type, COUNT(*)
FROM order_items INNER JOIN payments
ON order_items.order_id = payments.order_id
GROUP BY payments.order_value_segment, payments.payment_type
ORDER BY COUNT(*) DESC;

-------------------------------------------------------------------------------------

/*
Q2. Amazon India wants to analyse the price range and average price for each product 
category. Calculate the minimum, maximum, and average price for each category, and 
list them in descending order by the average price.
*/

SELECT product.product_category_name, MIN(order_items.price), MAX(order_items.price), AVG(order_items.price)
FROM product INNER JOIN order_items
ON product.product_id = order_items.product_id
GROUP BY product.product_category_name
ORDER BY AVG(order_items.price) DESC;


-------------------------------------------------------------------------------------

/*
Q3. Amazon India wants to identify the customers who have placed multiple orders over 
time. Find all customers with more than one order, and display their customer unique 
IDs along with the total number of orders they have placed.
*/

SELECT customers.customer_unique_id, COUNT(*) AS total_orders
FROM customers INNER JOIN orders
ON customers.customer_id = orders.customer_id
GROUP BY customers.customer_unique_id
HAVING COUNT(*) > 1
ORDER BY total_orders DESC;

-------------------------------------------------------------------------------------


/*
Q4. Amazon India wants to categorize customers into different types 
('New – order qty. = 1' ;  'Returning' –order qty. 2 to 4;  'Loyal' – order qty. >4) 
based on their purchase history. Use a temporary table to define these categories 
and join it with the customers table to update and display the customer types.
*/

WITH customer_type_table AS (
SELECT customers.customer_unique_id, 
        COUNT(*) AS total_orders,
        CASE 
            WHEN COUNT(*) = 1 THEN 'New'
            WHEN COUNT(*) BETWEEN 2 AND 4 THEN 'Returning'
            WHEN COUNT(*) > 4 THEN 'Loyal'
        END AS customer_type
FROM customers 
INNER JOIN orders
ON customers.customer_id = orders.customer_id
GROUP BY customers.customer_unique_id
ORDER BY total_orders DESC)

SELECT customers.customer_unique_id, customer_type_table.customer_type
FROM customers INNER JOIN customer_type_table
ON customers.customer_unique_id = customer_type_table.customer_unique_id;

-------------------------------------------------------------------------------------

/*
Q5. Amazon India wants to know which product categories generate the most revenue. 
Use joins between the tables to calculate the total revenue for each product category.
Display the top 5 categories.
*/


SELECT product.product_category_name, ROUND(SUM(order_items.price)::numeric,2) AS total_revenue
FROM order_items INNER JOIN product
ON order_items.product_id = product.product_id
GROUP BY product.product_category_name
ORDER BY SUM(order_items.price) DESC
LIMIT 5
OFFSET 0;

-------------------------------------------------------------------------------------

-- Analysis - III
/*
Q1. The marketing team wants to compare the total sales between different seasons. 
Use a subquery to calculate total sales for each season (Spring, Summer, Autumn, 
Winter) based on order purchase dates, and display the results. Spring is in the 
months of March, April and May. Summer is from June to August and Autumn is between 
September and November and rest months are Winter. 
*/

SELECT order_season.season, ROUND(SUM(order_items.price)::numeric,2) 
FROM (

SELECT 
	order_id,
	CASE
		WHEN EXTRACT(MONTH FROM order_purchase_timestamp) IN (3,4,5) THEN 'Spring'
		WHEN EXTRACT(MONTH FROM order_purchase_timestamp) IN (6,7,8) THEN 'Summer'
		WHEN EXTRACT(MONTH FROM order_purchase_timestamp) IN (9,10,11) THEN 'Autumn'
		ELSE 'Winter'
	END AS season 
FROM orders) AS order_season INNER JOIN order_items 

ON order_items.order_id = order_season.order_id
GROUP BY order_season.season;

-------------------------------------------------------------------------------------

/*
Q2. The inventory team is interested in identifying products that have sales volumes 
above the overall average. Write a query that uses a subquery to filter products 
with a total quantity sold above the average quantity.
*/

SELECT product_id, COUNT(*) AS total_quantities_sold
FROM order_items
GROUP BY product_id
HAVING COUNT(*) > (

SELECT AVG(product_quantities.quan_sold_per_product)
FROM (
SELECT COUNT(*) AS quan_sold_per_product 
FROM order_items
GROUP BY product_id
) AS product_quantities);

------------------------------------------------------------------------------------

/*
Q3. To understand seasonal sales patterns, the finance team is analysing the monthly 
revenue trends over the past year (year 2018). Run a query to calculate total revenue 
generated each month and identify periods of peak and low sales. Export the data to 
Excel and create a graph to visually represent revenue changes across the months. 
*/

SELECT EXTRACT(MONTH FROM orders.order_purchase_timestamp) as month_no, TO_CHAR(orders.order_purchase_timestamp, 'Month') AS month, SUM(order_items.price) AS total_revenue 
FROM orders
INNER JOIN order_items
ON orders.order_id = order_items.order_id
WHERE EXTRACT(YEAR FROM orders.order_purchase_timestamp) = 2018
GROUP BY EXTRACT(MONTH FROM orders.order_purchase_timestamp), TO_CHAR(orders.order_purchase_timestamp, 'Month')
ORDER BY month_no ASC;

--------------------------------------------------------------------------------------

/*
Q4. A loyalty program is being designed  for Amazon India. Create a segmentation 
based on purchase frequency: ‘Occasional’ for customers with 1-2 orders, ‘Regular’ 
for 3-5 orders, and ‘Loyal’ for more than 5 orders. Use a CTE to classify customers 
and their count and generate a chart in Excel to show the proportion of each segment.
*/

WITH loyalty AS (
SELECT customers.customer_unique_id, 
	CASE 
		WHEN COUNT(*) <= 2 THEN 'Occasional'
		WHEN COUNT(*) BETWEEN 3 AND 5 THEN 'Regular'
		ELSE 'Loyal'
	END AS customer_type 
FROM customers INNER JOIN orders
ON customers.customer_id = orders.customer_id
GROUP BY customers.customer_unique_id)

SELECT customer_type, COUNT(*) FROM loyalty
GROUP BY customer_type;

-------------------------------------------------------------------------------------

/*
Q5. Amazon wants to identify high-value customers to target for an exclusive rewards 
program. You are required to rank customers based on their average order value 
(avg_order_value) to find the top 20 customers.
*/

WITH avg_order_value_table AS (SELECT orders.customer_id, AVG(payment_value) as avg_order_value
FROM orders INNER JOIN payments
ON orders.order_id = payments.order_id
GROUP BY orders.customer_id), 
ranked_customers AS (
SELECT customer_id,
	ROUND(avg_order_value::numeric,2) as avg_order_value,
	DENSE_RANK() OVER (ORDER BY avg_order_value DESC) AS customer_rank
FROM avg_order_value_table
)

SELECT customer_id,avg_order_value,customer_rank  FROM ranked_customers
WHERE customer_rank <= 20;

-------------------------------------------------------------------------------------

/*
Q6. Amazon wants to analyze sales growth trends for its key products over their 
lifecycle. Calculate monthly cumulative sales for each product from the date of 
its first sale. Use a recursive CTE to compute the cumulative sales (total_sales) 
for each product month by month.
*/

WITH monthly_sales AS (
    SELECT 
        p.payment_type,
        DATE_TRUNC('month', o.order_purchase_timestamp)::DATE AS sale_month,
        SUM(p.payment_value) AS monthly_total
    FROM 
        payments p
    JOIN 
        orders o ON p.order_id = o.order_id
    WHERE 
        EXTRACT(YEAR FROM o.order_purchase_timestamp) = 2018
    GROUP BY 
        p.payment_type,
        DATE_TRUNC('month', o.order_purchase_timestamp)::DATE
),
sales_with_lag AS (
    SELECT 
        payment_type,
        sale_month,
        monthly_total,
        LAG(monthly_total) OVER (
            PARTITION BY payment_type 
            ORDER BY sale_month
        ) AS prev_monthly_total
    FROM 
        monthly_sales
)
SELECT 
    payment_type,
    sale_month,
    ROUND(monthly_total::NUMERIC, 2) AS monthly_total,
    ROUND(
        (
            (monthly_total - prev_monthly_total) / 
            NULLIF(prev_monthly_total, 0) * 100.0
        )::NUMERIC, 
        2
    ) AS monthly_change
FROM 
    sales_with_lag
ORDER BY 
    payment_type, 
    sale_month;

------------------------------------------------------------------------------------

/*
Q7. To understand how different payment methods affect monthly sales growth, 
Amazon wants to compute the total sales for each payment method and calculate 
the month-over-month growth rate for the past year (year 2018). Write query to 
first calculate total monthly sales for each payment method, then compute the 
percentage change from the previous month.
*/

WITH MonthlySales AS (
    SELECT 
        p.payment_type,
        DATE_TRUNC('month', o.order_purchase_timestamp)::DATE AS sale_month,
        ROUND(SUM(p.payment_value)::numeric, 2) AS monthly_total
    FROM payments p
    JOIN orders o 
        ON p.order_id = o.order_id
    WHERE EXTRACT(YEAR FROM o.order_purchase_timestamp) = 2018
    GROUP BY 
        p.payment_type,
        DATE_TRUNC('month', o.order_purchase_timestamp)
)
SELECT 
    payment_type,
    sale_month,
    monthly_total,
    ROUND(
        (
            (monthly_total - LAG(monthly_total) OVER (
                PARTITION BY payment_type 
                ORDER BY sale_month
            )) 
            / NULLIF(LAG(monthly_total) OVER (
                PARTITION BY payment_type 
                ORDER BY sale_month
            ), 0)
        ) * 100, 
        2
    ) AS monthly_change
FROM MonthlySales
ORDER BY 
    payment_type,
    sale_month;